#include "OgreHardwareBuffer.h"
#pragma message( __FILE__ " is deprecated, migrate to Ogre.h")
