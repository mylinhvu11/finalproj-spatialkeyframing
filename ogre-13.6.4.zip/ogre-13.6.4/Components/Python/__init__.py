from Ogre.Ogre import *
from Ogre.Ogre import __version__
