//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OgreWin32Resources.rc
//
#define IDD_DLG_VIDEO                   101
#define IDD_DLG_CONFIG                  101
#define IDI_ICON1                       103
#define IDB_SPLASH                      106
#define IDD_DLG_ERROR                   107
#define IDI_OGREICON                    111
#define IDC_CBO_VIDEO                   1001
#define IDC_VIDEO_MODE                  1002
#define ID_LBL_RES                      1003
#define IDC_CBO_RESOLUTION              1004
#define IDC_CBO_VIDEOMODE               1004
#define IDC_COLOUR_DEPTH                1005
#define IDC_CBO_COLOUR_DEPTH            1006
#define IDC_CHK_FULLSCREEN              1007
#define IDC_CBO_RENDERSYSTEM            1009
#define IDC_OPTFRAME                    1010
#define IDC_CBO_OPTION                  1011
#define IDC_LST_OPTIONS                 1013
#define IDC_LBL_OPTION                  1014
#define IDC_ERRMSG                      1018
#define IDC_SELECT_VIDEO                -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
